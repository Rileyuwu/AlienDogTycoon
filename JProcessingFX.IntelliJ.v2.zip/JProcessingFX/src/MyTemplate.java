import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class MyTemplate extends ProcessingFX {
    public static void main(String[] args) {
        launch(args);
    }

    public void setup(GraphicsContext pen) {

    }

    public void draw(GraphicsContext pen) {

    }
}
